﻿Public Class frmLogin

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Me.Hide()
        frmPrincipal.Visible = True

    End Sub
End Class